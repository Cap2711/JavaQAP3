

public class Demo {

    public static void main(String[] args) {
        //Create classes
        Person sam = new Person("Sam Johnson", 25, "M");
        Student emily = new Student("Emily Parker", 22, "F", "EP98765", 3.9);
        Teacher mrHart = new Teacher("Mr. Hart", 25, "M", "Drama", 55000);
        CollegeStudent lisa = new CollegeStudent("Lisa Roberts", 20, "F", "LR12345", 3.5, "Biology", 3);

        //Print out results
        System.out.println(sam);
        System.out.println(emily);
        System.out.println(mrHart);
        System.out.println(lisa);
    }
}
